def split(thing): 
    return [char for char in thing] 